﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace ProjetoEDA2.Classes
{
    class Maquina
    {
        public bool Executando { get; set; }
        public string TarefasExecutadas { get; set; }
        public Maquina()
        {
           
        }
        public static void main()
        {

        }
        public void ExecutaTarefa()
        {
            
        }
    }
}
